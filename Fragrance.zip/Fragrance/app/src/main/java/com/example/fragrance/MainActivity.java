package com.example.fragrance;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button rose, lily, lotus, sunflower;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rose = (Button) findViewById(R.id.b1);
        lily = (Button) findViewById(R.id.b2);
        lotus = (Button) findViewById(R.id.b3);
        sunflower = (Button) findViewById(R.id.b4);
        listener();
    }

    private void listener() {
        rose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction f1 = getSupportFragmentManager().beginTransaction();
                BlankFragment f11 = new BlankFragment();
                f1.replace(R.id.fragment_container, f11);
                f1.commit();
            }
        });

        lily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction f2 = getSupportFragmentManager().beginTransaction();
                BlankFragment2 f12 = new BlankFragment2();
                f2.replace(R.id.fragment_container, f12);
                f2.commit();
            }
        });

        lotus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction f3 = getSupportFragmentManager().beginTransaction();
                BlankFragment3 f13 = new BlankFragment3();
                f3.replace(R.id.fragment_container, f13);
                f3.commit();
            }
        });

        sunflower.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction f4 = getSupportFragmentManager().beginTransaction();
                BlankFragment4 f14 = new BlankFragment4();
                f4.replace(R.id.fragment_container, f14);
                f4.commit();
            }
        });

    }
}
